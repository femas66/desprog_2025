$(document).ready(function() {

    // Animasi fade-in saat halaman dimuat
    $('.container').hide().fadeIn(1000);

    // Interaksi hover pada tombol
    $('#tombolKirim').hover(
        function() {
            $(this).css('background-color', '#0056b3');
        },
        function() {
            $(this).css('background-color', '#007bff');
        }
    );

    $('#formPemesanan').on('submit', function(event) {
        // Hentikan pengiriman form default untuk validasi
        event.preventDefault();

        let isValid = true;

        // --- VALIDASI NAMA ---
        const nama = $('#nama').val().trim();
        if (nama === '') {
            isValid = false;
            $('#nama').next('.error-message').text('Nama tidak boleh kosong.').slideDown();
        } else {
            $('#nama').next('.error-message').slideUp();
        }

        // --- VALIDASI EMAIL ---
        const email = $('#email').val().trim();
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        if (email === '') {
            isValid = false;
            $('#email').next('.error-message').text('Email tidak boleh kosong.').slideDown();
        } else if (!emailPattern.test(email)) {
            isValid = false;
            $('#email').next('.error-message').text('Format email tidak valid.').slideDown();
        } else {
            $('#email').next('.error-message').slideUp();
        }

        // --- VALIDASI PILIHAN ACARA ---
        const acara = $('#acara').val();
        if (acara === '') {
            isValid = false;
            $('#acara').next('.error-message').text('Silakan pilih acara.').slideDown();
        } else {
            $('#acara').next('.error-message').slideUp();
        }
        
        // --- VALIDASI JUMLAH TIKET ---
        const jumlah = $('#jumlah').val();
        if (jumlah === '' || parseInt(jumlah) < 1) {
            isValid = false;
            $('#jumlah').next('.error-message').text('Jumlah tiket minimal 1.').slideDown();
        } else {
            $('#jumlah').next('.error-message').slideUp();
        }

        // Jika semua valid, kirim form
        if (isValid) {
            // Efek slideUp sebelum form dikirim
            $(this).slideUp(500, function() {
                // Menggunakan AJAX untuk mengirim data (Bagian Optional) [cite: 69]
                $.ajax({
                    type: 'POST',
                    url: $(this).attr('action'),
                    data: $(this).serialize(),
                    success: function(response) {
                        // Tampilkan hasil dari server tanpa reload [cite: 70]
                        $('#hasil-ajax').html(response).hide().fadeIn(1000);
                    },
                    error: function() {
                        alert('Terjadi kesalahan saat mengirim data.');
                        // Tampilkan kembali form jika gagal
                        $('#formPemesanan').slideDown();
                    }
                });
            });
        }
    });
});