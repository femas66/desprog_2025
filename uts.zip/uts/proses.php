<?php
session_start(); // Memulai session untuk menyimpan data sementara

// Inisialisasi array pesanan jika belum ada di session
if (!isset($_SESSION['daftar_pesanan'])) {
    $_SESSION['daftar_pesanan'] = [];
}

// Cek apakah data dikirim melalui metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Ambil dan bersihkan data dari form
    $nama = htmlspecialchars($_POST['nama']);
    $email = htmlspecialchars($_POST['email']);
    $acara = htmlspecialchars($_POST['acara']);
    $jumlah = (int)$_POST['jumlah'];

    // 2. Tentukan harga tiket berdasarkan acara
    $harga_tiket = 0;
    if ($acara == "Konser Musik Rock") {
        $harga_tiket = 500000;
    } elseif ($acara == "Festival Film Indonesia") {
        $harga_tiket = 250000;
    } elseif ($acara == "Pentas Seni Tradisional") {
        $harga_tiket = 150000;
    }

    // 3. Hitung total harga
    $total_harga = $harga_tiket * $jumlah;

    // 4. Simpan data pesanan ke dalam sebuah array asosiatif [cite: 35]
    $pesanan_baru = [
        'nama' => $nama,
        'email' => $email,
        'acara' => $acara,
        'jumlah' => $jumlah,
        'total_harga' => $total_harga
    ];

    // 5. Tambahkan pesanan baru ke dalam array utama di session [cite: 38, 39]
    $_SESSION['daftar_pesanan'][] = $pesanan_baru;

    // Karena menggunakan AJAX, kita langsung tampilkan output di sini
    // yang akan diterima oleh fungsi success di jQuery. [cite: 42, 43]
    
    // Tampilkan konfirmasi pesanan terbaru
    echo "<div class='hasil-container'>";
    echo "<h2>Pemesanan Berhasil!</h2>";
    echo "<p>Terima kasih, <strong>" . htmlspecialchars($pesanan_baru['nama']) . "</strong>. Detail pesanan Anda:</p>";
    echo "<div class='detail-pesanan'>";
    echo "<strong>Acara:</strong> " . htmlspecialchars($pesanan_baru['acara']) . "<br>";
    echo "<strong>Jumlah Tiket:</strong> " . htmlspecialchars($pesanan_baru['jumlah']) . "<br>";
    echo "<strong>Total Harga:</strong> Rp " . number_format($pesanan_baru['total_harga'], 0, ',', '.');
    echo "</div>";
    echo "</div>";

    // Tampilkan semua riwayat pesanan
    if (count($_SESSION['daftar_pesanan']) > 0) {
        echo "<h3>Riwayat Pemesanan:</h3>";
        echo "<ul>";
        foreach ($_SESSION['daftar_pesanan'] as $pesanan) {
            echo "<li>" . htmlspecialchars($pesanan['nama']) . " - " . htmlspecialchars($pesanan['acara']) . " (" . htmlspecialchars($pesanan['jumlah']) . " tiket)</li>";
        }
        echo "</ul>";
    }

} else {
    // Jika file diakses langsung, kembalikan ke halaman utama
    header("Location: index.html");
    exit();
}
?>

<style>
.hasil-container { text-align: center; margin-top: 20px; }
.hasil-container h2 { color: #2ecc71; }
.detail-pesanan { background-color: #f9f9f9; border-left: 5px solid #007bff; padding: 20px; margin-top: 20px; text-align: left; border-radius: 8px; }
h3 { margin-top: 30px; }
ul { list-style: none; padding: 0; text-align: left; }
li { background: #eee; padding: 10px; margin-bottom: 5px; border-radius: 5px; }
</style>